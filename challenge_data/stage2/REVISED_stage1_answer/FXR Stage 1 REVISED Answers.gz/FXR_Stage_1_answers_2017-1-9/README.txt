This tar file contains two top-level folders. Main-default contains a
full set of cocrystal structures refined with default planarity
restraints on planar ligand groups. SI-Tight contains a full set of the
same cocrystal structures refined with tightened planarity restraints.